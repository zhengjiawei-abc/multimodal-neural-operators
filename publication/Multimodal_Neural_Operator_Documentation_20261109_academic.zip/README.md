# Publication Package: Multimodal Neural Operator

This directory contains the final bilingual paper and technical documentation for the Burgers-equation multimodal neural operator.

## Deliverables

| Language | Paper | Technical document |
| --- | --- | --- |
| English | `multimodal_neural_operator_paper_en.md` | `multimodal_neural_operator_technical_document_en.md` |
| Chinese | `multimodal_neural_operator_paper_zh.md` | `multimodal_neural_operator_technical_document_zh.md` |

Generated PDFs are written to `pdf/`.

The exact metric values, source paths, and evidence status are recorded in
`evidence_summary.json`.

## Evidence Status

The documents use three evidence levels.

**Verified result:** exact periodic-shift augmentation, three paired seeds, mean test relative L2 improvement from 0.103485 to 0.097188.

**Preliminary result:** eight-sensor fusion is worse than the field-only reference in one seed. This is a negative engineering signal, not a causal fusion estimate.

**Unresolved comparison:** the archived cross-attention and pre-fusion labels have identical stored configurations and parameter signatures. Their outputs differ, but the difference cannot be attributed to fusion mode.

## Primary Sources

- Model and training: `../code/demo_burgers_dataset.py`
- Shift augmentation: `../code/make_custom_shift_augment.py`
- Original-data controls: `../experiments/outputs_burgers_dataset/custom_v7_hp05_24k*`
- Shifted runs: `../experiments/outputs_burgers_dataset/custom_v13_shift3_24k*`
- Sensor trial: `../experiments/outputs_burgers_dataset/custom_v11_multimodal_sensors8_24k/`
- Archived fusion label: `../experiments/outputs_burgers_dataset/custom_v12_multimodal_prefusion_24k/`
- Data: `../datasets/burgers_custom_v1/`

## Build PDFs

From the repository root:

```powershell
python publication\build_pdfs.py
```

The build requires the Python packages already used by `tmp/pdfs/build_all_documents_pdf.py`, including `markdown`, `playwright`, `pymupdf`, `pypdf`, and `reportlab`.

To validate source links, image paths, PDF page counts, metadata, and extracted text:

```powershell
python publication\validate_publication.py
```

## Scope

These documents cover only the multimodal neural operator for the Burgers equation. They do not describe the structural-health-monitoring classifier or the explainer-video materials.

