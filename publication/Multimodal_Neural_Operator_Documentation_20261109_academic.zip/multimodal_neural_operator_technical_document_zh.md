# 多模态神经算子技术文档：Burgers 方程实现、评测与复现

**文档类型**: 工程与复现手册
**版本**: 1.0
**日期**: 2026 年 11 月 8 日
**作者**: 项目维护者
**副标题**: 架构、数据、训练、评测与交付说明

---

## 1 目的与范围

本文档描述当前一维黏性 Burgers 方程多模态神经算子的工程实现，面向需要运行、检查、扩展或审计模型的人员。内容包括计算图、数据格式、周期平移增强、训练配置、评测逻辑、保留结果、已知问题和复现命令。

系统有两个成熟度层级。

纯场算子有三个随机种子的匹配增强实验支持。原始 1,408 条轨迹训练集与 4,224 条严格周期平移训练集在相同模型和优化预算下比较。

传感器路径已经实现，但尚未验证。八传感器初步运行差于纯场参考。当前传感器目标不包含跨模态对齐项，也不包含模态丢弃。

本文不讨论结构健康监测分类器、视频流程或其他无关实验。

## 2 系统概览

| 项目 | 当前值 |
| --- | --- |
| PDE | 一维黏性 Burgers |
| 空间域 | 周期 \(x\in[0,1)\) |
| 分辨率 | 256 个空间点，101 个时间点 |
| 黏性系数 | 0.004、0.006、0.008、0.01、0.012 |
| 初始场类型 | Fourier、混合场、弱高频、弱尖峰、弱台阶 |
| 主训练文件 | `burgers_custom_train_curriculum2_shift3.parquet` |
| 主训练样本 | 4,224 |
| 验证样本 | 128 |
| 同分布测试样本 | 128 |
| 主干 | CNN tokenizer、卷积流形、潜空间 ODE、Transformer 上下文、查询解码器 |
| 纯场参数量 | 336,546 |
| 八传感器参数量 | 341,026 |
| 主种子 | 11、7、23 |
| 主指标 | 全场相对 L2 |
| 诊断指标 | 随机查询 PDE RMS |

## 3 目录结构

| 路径 | 作用 |
| --- | --- |
| `code/demo_burgers_dataset.py` | 模型、训练、评测与 CLI |
| `code/make_custom_shift_augment.py` | 精确周期平移数据生成 |
| `code/make_custom_burgers.py` | 基础数据生成工具 |
| `datasets/burgers_custom_v1/` | Parquet 轨迹与元数据 |
| `experiments/outputs_burgers_dataset/custom_v7_hp05_24k*` | 原始数据三 seed 对照 |
| `experiments/outputs_burgers_dataset/custom_v13_shift3_24k*` | 周期平移三 seed 运行 |
| `experiments/outputs_burgers_dataset/custom_v11_multimodal_sensors8_24k/` | 八传感器试验 |
| `experiments/outputs_burgers_dataset/custom_v12_multimodal_prefusion_24k/` | 存档融合标签运行 |
| `code/figures/fig1_architecture.png` | 论文使用的架构图 |
| `publication/` | 当前论文和技术文档源文件 |

## 4 数据契约

### 4.1 轨迹形状

每个样本是一条完整时空场，逻辑形状为

$$
u\in\mathbb{R}^{256\times101}.
$$

加载器返回张量形状 `[batch, nx, nt, 1]`。第一个时间切片作为初始场 \(u_0\)，完整场作为预测目标。

### 4.2 数据划分

| 文件 | 轨迹数 | 作用 |
| --- | ---: | --- |
| `burgers_custom_train_curriculum2.parquet` | 1,408 | 原始训练集 |
| `burgers_custom_train_curriculum2_shift3.parquet` | 4,224 | 严格周期平移训练集 |
| `burgers_custom_dev.parquet` | 128 | 验证与检查点选择 |
| `burgers_custom_test_id.parquet` | 128 | 同分布测试 |
| `burgers_custom_test_ood.parquet` | 128 | 台阶 OOD |
| `burgers_custom_test_ood2.parquet` | 128 | 尖峰 OOD |
| `burgers_custom_test_ood3.parquet` | 128 | 高频 OOD |

OOD 文件存在，但核心论文表使用的 `metrics.json` 没有保存 OOD 指标。除非重新运行评测，否则不应凭记忆或二次总结引用 OOD 数字。

### 4.3 元数据

每个 Parquet 文件都有同名 `.meta.json` 数组。每条记录至少包含：

- `family`：初始场类型；
- `nu`：黏性系数；
- 增强样本额外包含 `augmentation`、`shift`、`copy`。

原始训练集包含：

| 类型 | 数量 |
| --- | ---: |
| Fourier | 512 |
| 混合场 | 512 |
| 弱高频 | 128 |
| 弱尖峰 | 128 |
| 弱台阶 | 128 |

黏性分布为：

| 黏性系数 | 训练数量 |
| ---: | ---: |
| 0.004 | 295 |
| 0.006 | 330 |
| 0.008 | 251 |
| 0.010 | 267 |
| 0.012 | 265 |

### 4.4 数据完整性检查

训练前应检查：

1. 所选训练文件位于 `--data-dir`。
2. 元数据数组长度等于轨迹数。
3. 所有场值有限。
4. 每条轨迹的第一个时间切片不是常数。
5. 平移样本的 `shift` 是 `[1, nx-1]` 内整数。

当前加载器会检查文件读取和张量形状，但不会在每次运行中执行完整元数据对行审计和全量有限值审计。

## 5 模型结构

![图 1 当前多模态计算图](publication/assets/architecture_zh.png)

图 1 当前场、潜变量、传感器、上下文和查询路径。

### 5.1 场路径

构造高通通道：

$$
h(u_0)=u_0-\operatorname{AvgPool}_{15}(u_0),
$$

平均池化前使用周期填充。CNN 输入为

$$
[u_0,\,0.5h(u_0)].
$$

Tokenizer 包含：

1. `Conv1d(2, 16, kernel=5)`，周期填充；
2. SiLU；
3. `Conv1d(16, 32, kernel=5)`，周期填充；
4. SiLU；
5. 自适应平均池化到 32 个位置；
6. 线性投影到宽度 64。

### 5.2 流形路径

卷积流形自编码器把初始场编码为 32 维潜变量。主目标训练前先进行 1,500 步重建预训练。主模型通过两种方式注入流形信息：

- 潜变量的线性投影加到每个空间 token；
- 流形 CNN 分支把潜变量重塑为 token 场，再注入特征。

流形 CNN 分支包含 8,320 个参数。

### 5.3 上下文编码器

上下文编码器是标准 pre-norm Transformer：

| 配置 | 数值 |
| --- | ---: |
| 宽度 | 64 |
| 层数 | 3 |
| 注意力头 | 4 |
| 场 token 位置 | 32 |
| 额外 token | 流形 token 和可选传感器 token |

上下文 token 的实际数量取决于是否启用流形 CNN 注入以及是否存在传感器。由于初始场位置之后不再应用固定位置表，编码器可以接受可变 token 数。

### 5.4 时间路径

潜状态通过 4 步显式 Euler 积分：

$$
z_{k+1}=z_k+\Delta t\,v_\theta(z_k),
\qquad
\Delta t=t/4.
$$

向量场是隐藏宽度 64 的两层 MLP，包含 8,352 个参数。

### 5.5 查询解码器

查询表示拼接：

- \(x\)、\(t\) 的 Fourier 特征；
- 演化后的潜状态 \(z(t)\)；
- 局部初始场特征。

解码流程为：

1. 查询投影到宽度 64；
2. 对上下文 token 做交叉注意力；
3. 残差归一化和前馈块；
4. 输出头 `64 -> 32 -> 1`。

评测把全场分成每块 4,096 个查询，避免显存峰值过高。

### 5.6 传感器路径

当 `--sensor-count N` 大于 0 时，模型选择 `N` 个等间隔空间索引和由 `--sensor-time` 确定的固定时间索引。每个传感器 token 为

$$
T_s^{(i)}=\operatorname{MLP}([x_i,t_s,u_i])+e_{\mathrm{sensor}}.
$$

MLP 为 `3 -> 64 -> SiLU -> 64 -> 64`。传感器 token 在上下文 Transformer 之前与场 token 拼接。

当前实现对每个样本使用固定传感器布局。它不随机化测点位置，不使用模态丢弃，也没有显式要求测点值与预测场一致的损失项。

## 6 损失与优化

### 6.1 损失项

| 损失项 | 作用 | 主运行状态 |
| --- | --- | --- |
| 数据 | 在随机场点匹配预测值 | 启用 |
| 初始条件 | 匹配 \(t=0\) 的预测 | 启用 |
| 周期边界 | 匹配 \(x=0,1\) 处的值和可选导数 | 启用 |
| PDE 残差 | 自动微分约束 Burgers 方程 | 权重 0.0 |
| 重建 | 保持流形重建 | 通过预训练和正则项启用 |

损失平衡器用运行参考缩放活跃项。核心运行使用：

- `loss_balance=True`；
- `loss_floor=1e-3`；
- `loss_balance_warmup=500`；
- `physics_weight=0.0`；
- `validation_physics_weight=0.1`。

### 6.2 核心配置

| 参数 | 数值 |
| --- | ---: |
| `preset` | `wide` |
| `train_samples` | 4,224 |
| `dev_samples` | 128 |
| `test_samples` | 128 |
| `eval_samples` | 128 |
| `nx` | 256 |
| `nt` | 101 |
| `latent_dim` | 32 |
| `manifold_hidden` | 256 |
| `conv_ae_channels` | 16 |
| `cnn_channels` | 32 |
| `cnn_kernel_size` | 5 |
| `token_count` | 32 |
| `d_model` | 64 |
| `n_heads` | 4 |
| `n_layers` | 3 |
| `head_width` | 32 |
| `ode_steps` | 4 |
| `batch_size` | 32 |
| `steps` | 24,000 |
| `lr` | 1e-3 |
| `lr_decay_steps` | 24,000 |
| `warmup_steps` | 200 |
| `min_lr_ratio` | 0.02 |
| `dropout` | 0.1 |
| `grad_clip_norm` | 1.0 |
| `eval_every` | 1,000 |
| `early_stop_patience` | 100 |
| `manifold_steps` | 1,500 |

保留运行的配置早于显式 optimizer 和 weight decay 字段。使用当前 `wide` 预设直接重跑会采用 AdamW 和权重衰减。为复现保留配方，必须在命令行显式指定 optimizer 和 weight decay，见第 9 节。

### 6.3 检查点规则

训练循环保存验证分数最低的状态：

$$
s_{\mathrm{dev}}=L_2^{\mathrm{dev}}
+0.1\,\mathrm{PDE}_{\mathrm{RMS}}^{\mathrm{dev}}.
$$

训练结束后在 train、dev、test 评测前恢复最佳状态。`model.pt` 保存同一最佳状态。

| 种子 | 最佳步数 | 完成步数 |
| ---: | ---: | ---: |
| 11 | 22,000 | 24,000 |
| 7 | 20,000 | 24,000 |
| 23 | 18,000 | 24,000 |

## 7 严格周期平移增强

### 7.1 数学依据

对周期 Burgers 动力学，精确解的空间平移仍然是精确解：

$$
u(x,t)\longrightarrow u(x-\delta,t).
$$

幅度、黏性、边界条件和导数算子都不改变。因此，这是对称变换，而不是启发式扰动。

### 7.2 生成器行为

`code/make_custom_shift_augment.py` 执行：

1. 读取 `burgers_custom_train_curriculum2.parquet`。
2. 读取同名元数据。
3. 保留原始 1,408 条场。
4. 对两个额外副本，为每条轨迹抽一个随机整数平移。
5. 执行 `numpy.roll(field, shift, axis=0)`。
6. 复制元数据并添加 `augmentation`、`shift`、`copy`。
7. 保存 4,224 条轨迹和元数据。

随机数生成器为 `numpy.random.default_rng(101)`。

### 7.3 设计约束

- 空间域必须周期。
- 平移作用于完整时空场，而不是只平移初始切片。
- 平移量必须是整数个网格单元。
- 变换改变位置覆盖，但不改变轨迹物理身份。
- 增强副本不是独立数值仿真，不能当作独立物理样本计数。

## 8 评测

### 8.1 相对 L2

对每条评测轨迹，

$$
e_m=\frac{\lVert\hat{u}_m-u_m\rVert_2}
{\lVert u_m\rVert_2}.
$$

报告值是对测试轨迹取平均的 `mean(e_m)`。

### 8.2 PDE 残差

评测器随机采样 128 个 \((x,t)\)，计算 \(\hat{u}\)，通过自动微分得到一阶和二阶导数，再计算

$$
r=\hat{u}_t+\hat{u}\hat{u}_x-\nu\hat{u}_{xx}.
$$

保存值为 \(\sqrt{\mathbb{E}[r^2]}\)。

有两个实现问题需要注意：

1. 评测查询坐标没有保存固定种子。
2. 残差使用 `cfg.nu`，当前为 0.01，而数据包含多个黏性系数。

因此，该残差是稳定性和合理性诊断，不是标定后的物理误差。

### 8.3 训练诊断

`metrics.json` 还包含：

- 最大、平均和被裁剪的梯度范数；
- 损失平衡参考；
- 最佳验证分数与步数；
- 连续无改善评估次数；
- 测试与训练分离度；
- 流形预训练历史；
- 完整训练历史。

## 9 复现命令

所有命令从仓库根目录执行。

### 9.1 重新生成严格平移数据

```powershell
python code\make_custom_shift_augment.py --extra-copies 2 --output-name burgers_custom_train_curriculum2_shift3.parquet
```

预期摘要：

```json
{
  "base": "burgers_custom_train_curriculum2.parquet",
  "augmentation": "exact periodic shift along x",
  "extra_copies": 2,
  "total": 4224
}
```

### 9.2 训练纯场平移模型

```powershell
python code\demo_burgers_dataset.py `
  --data-dir datasets\burgers_custom_v1 `
  --train-file burgers_custom_train_curriculum2_shift3.parquet `
  --dev-file burgers_custom_dev.parquet `
  --test-file burgers_custom_test_id.parquet `
  --train-samples 4224 --dev-samples 128 --test-samples 128 `
  --preset wide --steps 24000 --lr-decay-steps 24000 `
  --batch-size 32 --lr 0.001 --warmup-steps 200 `
  --dropout 0.1 --input-highpass --highpass-scale 0.5 --highpass-kernel 15 `
  --manifold-cnn --latent-ode --query-local-features `
  --optimizer adam --weight-decay 0 --manifold-weight-decay 0 `
  --physics-weight 0 --validation-physics-weight 0.1 `
  --loss-balance --loss-balance-warmup 500 `
  --manifold-steps 1500 --eval-every 1000 --early-stop-patience 100 `
  --save-model --seed 11 `
  --output-dir experiments\outputs_burgers_dataset\repro_shift3_seed11
```

分别把 `--seed 7` 和 `--seed 23` 代入，并修改输出目录。

### 9.3 训练原始数据对照

使用相同命令，把以下两项改为：

```text
--train-file burgers_custom_train_curriculum2.parquet
--train-samples 1408
```

种子、模型和优化设置必须匹配。不要把一个优化器下的原始数据结果与另一个优化器下的平移结果直接比较。

### 9.4 训练八传感器模型

加入：

```text
--sensor-count 8
--sensor-time 0.5
```

当前在线平移与传感器不兼容，因此不要同时传入 `--online-shift-augment`。

## 10 保留结果

### 10.1 三 seed 匹配比较

| 种子 | 原始 L2 | 平移 L2 | 相对变化 |
| ---: | ---: | ---: | ---: |
| 11 | 0.097000 | 0.090097 | -7.12% |
| 7 | 0.102857 | 0.095846 | -6.82% |
| 23 | 0.110597 | 0.105622 | -4.50% |
| 平均 | 0.103485 | 0.097188 | -6.09% |

平移组跨种子标准差为 0.007849。

### 10.2 PDE 残差

| 种子 | 原始 PDE | 平移 PDE |
| ---: | ---: | ---: |
| 11 | 0.838240 | 0.855308 |
| 7 | 1.354726 | 1.738279 |
| 23 | 1.524887 | 1.471190 |
| 平均 | 1.239284 | 1.354926 |

残差没有一致改善。后续报告应继续保留这一结果。

### 10.3 传感器试验

| Seed 11 | 纯场 | 八传感器 |
| --- | ---: | ---: |
| 测试 L2 | 0.097000 | 0.115319 |
| 测试 PDE RMS | 0.838240 | 1.038709 |
| 参数 | 336,546 | 341,026 |

传感器分支增加 4,480 个参数，在该运行中使两个记录指标都变差。

### 10.4 存档融合标签运行

`custom_v11_multimodal_sensors8_24k` 与 `custom_v12_multimodal_prefusion_24k` 的保存配置逐字段相同。两者都有 341,026 个参数和匹配的检查点签名，但输出不同：

| 指标 | `custom_v11` | `custom_v12` |
| --- | ---: | ---: |
| 测试 L2 | 0.115319 | 0.114495 |
| 测试 PDE | 1.038709 | 1.795859 |
| 训练时间（秒） | 1,597.907 | 1,374.561 |

不能根据现有证据把差异归因于融合方式。

## 11 已知问题与风险

### 11.1 历史配置漂移导致复现风险

当前 `DatasetConfig` 默认值和 `wide` 预设已经随代码演进。只传 `--preset wide` 无法复现历史运行。必须记录并显式传递 optimizer、dropout、warmup 和损失设置。

### 11.2 缺少架构清单

运行会保存 `metrics.json`，可选保存 `model.pt`，但不会保存模块名、参数形状哈希、代码哈希和融合模式。当前目录名被当作标签使用，这不足以支撑因果比较。

### 11.3 PDE 随机评测

残差随随机查询位置变化。如果查询集不固定，就不应直接比较不同运行，除非估计采样方差。

### 11.4 残差使用名义黏性

PDE 评测只使用单一 `cfg.nu`，而数据包含多个黏性系数。在把残差当作物理误差之前，应先改为使用样本对应系数。

### 11.5 固定传感器几何

传感器分支使用固定等间隔位置和单一时采样时刻。模型可能学习位置捷径。后续应测试随机布局、多采样时刻、缺失传感器和噪声。

### 11.6 没有多模态对齐

传感器 token 只被拼接，没有显式要求其与场预测一致。在判断传感器是否有效前，应先加入论文中的对齐目标。

### 11.7 单一 PDE

代码包含网格和谱解码器变体，但保留证据只涉及一维周期 Burgers 数据上的查询解码器。没有新实验时，不应把结论迁移到二维流动、非规则区域或非周期边界。

## 12 交付清单

### 运行前

- [ ] 选择准确的 Parquet 文件和样本数。
- [ ] 检查元数据长度和增强字段。
- [ ] 记录代码哈希。
- [ ] 记录全部非默认 CLI 参数。
- [ ] 确认 train、dev、test 文件互不重叠。
- [ ] 确认传感器数量和采样时刻。
- [ ] 分别确认训练物理权重和验证物理权重。

### 运行中

- [ ] 前 100 步检查损失是否有限。
- [ ] 检查梯度裁剪频率。
- [ ] 检查最佳验证步数不是零。
- [ ] 监控显存。

### 运行后

- [ ] 保存 `metrics.json`。
- [ ] 若后续还要分析，保存 `model.pt`。
- [ ] 核对参数量。
- [ ] 保存完整命令行。
- [ ] 保存架构指纹。
- [ ] 与匹配种子和预算比较。
- [ ] 报告负指标，不只报告最好指标。

## 附录 A 数据来源字段

每个平移元数据包含原始记录以及：

```json
{
  "augmentation": "periodic_shift",
  "shift": 123,
  "copy": 1
}
```

`copy` 标识增强副本，`shift` 是整数网格位移。两者都不改变底层物理系数。

## 附录 B 输出文件

| 文件 | 内容 |
| --- | --- |
| `metrics.json` | 配置、指标、稳定性、历史 |
| `model.pt` | 最佳 state dict、配置、参数量 |
| `training_curve.png` | 训练与验证曲线 |
| `test_prediction.png` | 第一条测试轨迹预测 |

预测图是视觉诊断，不是完整误差报告。每张图都应与对应 `metrics.json` 一起保存。

