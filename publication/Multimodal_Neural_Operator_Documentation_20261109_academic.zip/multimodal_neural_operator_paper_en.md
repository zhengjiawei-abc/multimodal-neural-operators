# Evidence-Audited Multimodal Neural Operators for the Burgers Equation

**Document type**: Research manuscript, preprint draft
**Version**: 1.0
**Date**: 8 November 2026
**Author**: Project author information to be completed
**Running Title**: Periodic-shift augmentation and sensor-fusion limits

---

## Abstract

Multimodal neural operators promise to combine dense field observations with sparse sensor measurements while retaining the mesh-independent inference interface of operator learning. This paper studies that promise on the one-dimensional viscous Burgers equation. We describe a composable operator that encodes an initial field into convolutional tokens and a low-dimensional latent state, evolves the latent state in time, and decodes arbitrary space-time queries through cross-attention. Sensor readings are projected into the same token space and concatenated with field tokens before the context encoder. This design is best described as hybrid token fusion: it combines early token concatenation with later query attention rather than implementing a pure early-fusion or pure late-fusion architecture.

We report two evidence streams. First, an exact periodic-shift augmentation expands 1,408 training trajectories to 4,224 by rolling complete space-time solutions along the periodic spatial direction. Across three paired seeds, the mean test relative L2 error decreases from 0.103485 to 0.097188, a 6.09% relative reduction. All three paired runs improve, and the development error improves in all three runs. The PDE residual does not improve consistently, so the result supports a data-coverage benefit rather than a general physical-consistency gain.

Second, an audit of two archived runs labelled as cross-attention and pre-fusion finds identical stored model configurations, identical parameter counts, and no independent pre-fusion control in the training entry point. Their numerical outputs differ, but the evidence cannot attribute the difference to fusion strategy. A preliminary eight-sensor trial also underperforms a matched field-only reference. We therefore treat direct sensor fusion as a negative result and specify the alignment objectives, modality dropout, paired-seed design, and architecture fingerprint needed for a valid follow-up. The central conclusion is deliberately narrow: exact symmetry augmentation is supported on the tested Burgers benchmark, while the multimodal fusion benefit remains unproven.

**Keywords**: neural operator; multimodal learning; sensor fusion; Burgers equation; periodic augmentation; reproducibility

## 1 Introduction

Neural operators learn mappings between function spaces and can approximate PDE solution operators at inference times that are independent of a fixed numerical mesh [1-4]. Most operator benchmarks assume a single, well-defined input field. Engineering systems rarely provide only one observation type. A simulation may supply a dense initial field, while an inspection system supplies a small number of point sensors. A weather model may combine satellite fields with ground stations. A structural monitoring system may combine full-field measurements with a sparse sensor network.

Combining these observations creates a design question: where should modalities first interact, which parameters should be shared, and how can a model distinguish information from different physical sources? A common narrative compares early feature fusion with late attention fusion and expects one strategy to win on accuracy and the other on physical consistency. That narrative is appealing, but it requires implementations that are independently identifiable, matched training budgets, repeated seeds, and an evaluation protocol that isolates the fusion mechanism from unrelated changes.

This paper returns to the saved artifacts of the project and asks which claims they support. The result is more constrained than the initial narrative. Two archived runs carry different fusion labels and different outputs, but their stored configurations and parameter signatures do not establish two distinct architectures. At the same time, a later single-modal experiment provides a cleaner positive result: exact periodic shifting improves three paired runs without changing the PDE, the resolution, the model size, or the optimization budget.

The paper makes four contributions.

1. It specifies the implemented multimodal operator as a concrete computation graph, including the hybrid nature of its token fusion path.
2. It establishes a reproducible positive result for exact periodic-shift augmentation on a three-seed matched comparison.
3. It audits the archived fusion comparison and replaces causal language with descriptive reporting where the artifacts do not support attribution.
4. It reports a preliminary negative sensor-fusion result and defines the controls required before a multimodal benefit can be claimed.

The scope is intentionally limited to a one-dimensional Burgers benchmark. The paper does not claim a general fusion law, a state-of-the-art PDE solver, or an engineering-grade surrogate.

## 2 Problem and Evidence Base

### 2.1 Governing equation

The benchmark solves the viscous Burgers equation

$$
\frac{\partial u}{\partial t}+u\frac{\partial u}{\partial x}
=\nu\frac{\partial^2 u}{\partial x^2},
\qquad x\in[0,1),\quad t\in[0,1],
$$

with periodic spatial boundary conditions. The stored fields use 256 spatial points and 101 time points. The dataset spans five viscosity values, \(\nu\in\{0.004,0.006,0.008,0.01,0.012\}\), and five initial-field families: Fourier, mixture, weak high-frequency, weak spike, and weak step. The learning problem is to approximate the solution operator from an initial field,

$$
\mathcal{G}:u_0(x)\mapsto u(x,t),
$$

and, in the multimodal setting, from an initial field plus sparse sensor values

$$
\mathcal{G}: \left(u_0(x),\,\{(x_i,t_s,u_i)\}_{i=1}^{N}\right)
\mapsto u(x,t).
$$

The dense modality is the initial field. The sparse modality consists of point values sampled at fixed spatial locations and a fixed time \(t_s\). The current implementation supports \(N>0\), but the best-supported results in this paper use \(N=0\). That distinction is central: the operator backbone is mature enough for a matched augmentation study, while the sensor branch remains exploratory.

### 2.2 Data splits

All retained comparisons use the same custom Burgers data family. The original curriculum split contains 1,408 training trajectories, 128 development trajectories, and 128 in-distribution test trajectories. The training split is dominated by 512 Fourier and 512 mixture fields, with 128 samples from each of the three weak curriculum families. The test split contains Fourier and mixture fields across the same five viscosity values. Additional out-of-distribution files exist in the data directory, but the paired three-seed comparison in this paper uses the saved in-distribution test split. A claim about OOD behavior is therefore outside the verified result table.

| Split | Trajectories | Spatial points | Time points |
| --- | ---: | ---: | ---: |
| Training, original | 1,408 | 256 | 101 |
| Training, shifted | 4,224 | 256 | 101 |
| Development | 128 | 256 | 101 |
| In-distribution test | 128 | 256 | 101 |

### 2.3 Evidence rule

The audit follows a simple rule. A numerical claim is retained only when it can be connected to a saved `metrics.json`, a checkpoint signature, a recorded configuration, or an executable code path. When the connection is indirect, the claim is downgraded. When the artifacts contradict the claim, the claim is removed.

A directory name is not treated as evidence of an architecture. A path containing `prefusion`, for example, is a label. It does not prove that the model executed a separate pre-fusion computation graph.

## 3 Multimodal Operator Architecture

### 3.1 Interface

The operator maps an initial field and optional sensors to a query value,

$$
\hat{u}(x,t)
=G_\theta\left(u_0,\{(x_i,t_s,u_i)\}_{i=1}^{N}\right)(x,t).
$$

The output can be evaluated at arbitrary coordinates after training. The model does not generate a fixed grid as an intermediate requirement. The retained implementation uses a query decoder, with optional grid decoders available in the codebase but not used in the experiments reported here.

![Figure 1. Multimodal operator backbone](publication/assets/architecture_en.png)

Figure 1. Field encoding, latent evolution, sensor-token fusion, context encoding, and query decoding. The sensor path is active only when `--sensor-count` is positive.

### 3.2 Field encoder

The initial field is first transformed into a high-pass representation,

$$
h(u_0)=u_0-\operatorname{smooth}_{15}(u_0),
$$

and the network receives the concatenation \([u_0,0.5h(u_0)]\). A two-layer one-dimensional CNN maps this input to local features. Adaptive average pooling produces 32 spatial tokens, which are projected to a model width of 64. The same field is encoded by a convolutional manifold autoencoder into a 32-dimensional latent state \(z_0\). A learned projection adds manifold information to the token sequence, and a manifold CNN branch injects a second latent-derived token representation.

The field encoding can be summarized as

$$
T_f=\operatorname{CNN}([u_0,0.5h(u_0)]),
\qquad
z_0=\operatorname{Enc}_{\mathrm{manifold}}(u_0),
\qquad
C_f=\Phi_f(T_f,z_0).
$$

The manifold encoder is pretrained before the operator objective is optimized. The retained runs use 1,500 pretraining steps.

### 3.3 Latent temporal evolution

The latent state evolves through a learned vector field,

$$
\frac{dz}{dt}=v_\theta(z),
\qquad
z(t)=z_0+\int_0^t v_\theta(z(s))\,ds.
$$

The implementation uses four explicit Euler steps. This is a compact continuous-time prior, not a high-accuracy ODE solver. It gives the decoder a query-dependent latent state without requiring a separate full-grid rollout.

### 3.4 Sensor tokens and hybrid fusion

For each sensor, the model receives position, sampling time, and value. A two-layer MLP projects the triple to the 64-dimensional model width, and a learned sensor-type embedding is added:

$$
T_s^{(i)}=\operatorname{MLP}([x_i,t_s,u_i])+e_{\mathrm{sensor}}.
$$

The sensor tokens are concatenated with the field and latent tokens before the context Transformer:

$$
C=\Phi_{\mathrm{context}}\left([T_f;T_{z_0};T_s]\right).
$$

The context encoder has three layers, four attention heads, and model width 64. The query decoder then attends to \(C\). This means the implementation is neither the idealized early-fusion design nor the idealized late-fusion design used in the earlier narrative. It performs early token-level concatenation followed by later query-based attention.

The distinction matters. Calling the model "late fusion" would hide the fact that sensor tokens enter the context encoder. Calling it "early fusion" would hide the decoder attention path. The correct descriptor is hybrid token fusion.

### 3.5 Query decoder

For a query coordinate \((x,t)\), the decoder builds

$$
q(x,t)=\operatorname{MLP}\left[
\gamma(x,t),\,z(t),\,u_0^{\mathrm{local}}(x)
\right],
$$

where \(\gamma\) contains Fourier coordinate features and \(u_0^{\mathrm{local}}\) contains local field features. The query is refined by cross-attention over the context,

$$
\tilde{q}(x,t)=\operatorname{Attn}(q,C,C),
\qquad
\hat{u}(x,t)=\operatorname{Head}\left(\operatorname{FFN}(\tilde{q})\right).
$$

The context is independent of the query count, so evaluation can process arbitrary space-time coordinates in chunks. The retained evaluation uses 4,096-query chunks.

### 3.6 Parameter scale

The three-seed field-only model contains 336,546 parameters. Adding eight sensors increases the count to 341,026. The parameter breakdown of the eight-sensor checkpoint is shown below.

| Component | Parameters |
| --- | ---: |
| Manifold encoder | 131,633 |
| Context encoder | 100,416 |
| Manifold-to-token projection | 33,792 |
| Temporal vector field | 8,352 |
| Query projection | 9,408 |
| Cross-attention | 16,640 |
| Feed-forward decoder | 16,576 |
| CNN tokenizer | 2,768 |
| Field-to-token projection | 2,112 |
| Latent-to-token projection | 2,112 |
| Manifold CNN branch | 8,320 |
| Sensor MLP projection | 4,416 |
| Position and sensor-type embeddings | 2,112 |
| Output head and normalization | 2,369 |
| Total | 341,026 |

## 4 Training and Evaluation Protocol

### 4.1 Exact periodic-shift augmentation

The spatial domain is periodic. For any exact solution \(u(x,t)\), the translated field

$$
u_\delta(x,t)=u(x-\delta,t)
$$

is also an exact solution with the same equation, boundary conditions, and viscosity. The augmentation therefore changes positional coverage without changing the physics.

The generator starts from 1,408 trajectories. It creates two additional copies of each trajectory and rolls the full space-time field by a random integer offset in \(\{1,\ldots,255\}\). This gives three copies per trajectory and 4,224 training samples. The random generator is seeded, and the augmentation metadata records the shift and copy index.

This operation is stronger evidence than arbitrary amplitude scaling or spectral perturbation because it cannot create a non-solution. It remains limited to periodic problems.

### 4.2 Objective

The training objective contains a data loss at sampled space-time points, an initial-condition loss, a periodic-boundary loss, and an optional PDE residual term. The retained core runs use

$$
\mathcal{L}
=\mathcal{L}_{\mathrm{data}}
+\mathcal{L}_{\mathrm{IC}}
+\mathcal{L}_{\mathrm{BC}}
+\lambda_{\mathrm{PDE}}\mathcal{L}_{\mathrm{PDE}},
\qquad
\lambda_{\mathrm{PDE}}=0.
$$

The PDE term is disabled in the optimization objective of the retained runs. The validation score uses a nonzero diagnostic weight,

$$
s_{\mathrm{dev}}
=L_2^{\mathrm{dev}}
+0.1\,\mathrm{PDE}_{\mathrm{RMS}}^{\mathrm{dev}}.
$$

Loss balancing is enabled for the active terms. The residual is evaluated with a nominal viscosity of 0.01, while the data contain multiple viscosity values. Because the PDE term is inactive during optimization, this does not alter the training objective, but it further limits the residual to a coarse project-internal diagnostic. The setup is better described as a data-driven operator with physical diagnostics than as a fully physics-informed optimizer.

### 4.3 Optimization

| Setting | Value |
| --- | ---: |
| Preset | wide |
| Training samples | 4,224 |
| Steps | 24,000 |
| Batch size | 32 |
| Learning rate | 1e-3 |
| Warmup | 200 steps |
| Schedule | cosine decay to 2% |
| Dropout | 0.1 |
| Gradient clip | 1.0 |
| Loss balancing | enabled |
| Physics weight | 0.0 |
| Validation physics weight | 0.1 |
| Seeds | 11, 7, 23 |

The best development checkpoint is restored before test evaluation. The retained best steps are 22,000, 20,000, and 18,000 for seeds 11, 7, and 23 respectively.

### 4.4 Metrics

Relative L2 error is computed over the full \(256\times101\) field and averaged over test trajectories:

$$
L_2^{\mathrm{rel}}
=\frac{1}{M}\sum_{m=1}^{M}
\frac{\lVert\hat{u}_m-u_m\rVert_2}
{\lVert u_m\rVert_2}.
$$

The PDE residual is evaluated on 128 sampled space-time points using automatic differentiation and reported as a root-mean-square value. Two details limit interpretation. The query coordinates are sampled at evaluation time, and the residual uses the nominal viscosity 0.01 for a dataset that spans multiple viscosities. The residual is therefore a coarse project-internal diagnostic, not a standardized cross-paper benchmark. Future comparisons should fix and save the evaluation query set and use the sample-specific viscosity.

## 5 Audit of the Archived Fusion Comparison

### 5.1 Stored configurations

The audit examines two run directories:

- `experiments/outputs_burgers_dataset/custom_v11_multimodal_sensors8_24k`
- `experiments/outputs_burgers_dataset/custom_v12_multimodal_prefusion_24k`

Both stored configurations contain eight sensors at \(t_s=0.5\), model width 64, 32 context tokens, four attention heads, three Transformer layers, batch size 32, 24,000 steps, learning rate \(10^{-3}\), training physics weight 0.0, validation physics weight 0.1, loss balancing enabled, and seed 11. A field-by-field comparison of the two saved configuration objects finds no difference.

Both checkpoints contain 341,026 parameters and 129 state-dict entries with matching tensor shapes. The weights themselves differ, which is compatible with two training runs of the same computation graph under different initialization or data order. The parameter signature does not establish two fusion mechanisms.

### 5.2 Descriptive measurements

| Measurement | Run labelled cross-attention | Run labelled pre-fusion |
| --- | ---: | ---: |
| Test relative L2 | 0.115319 | 0.114495 |
| Test PDE RMS | 1.038709 | 1.795859 |
| Development relative L2 | 0.128933 | 0.130875 |
| Training relative L2 | 0.118823 | 0.121072 |
| Training time (s) | 1,597.907 | 1,374.561 |
| Parameters | 341,026 | 341,026 |

The recorded test L2 difference is 0.000824, or 0.714% relative to the cross-attention-labelled run. The recorded PDE difference is 0.757150, with the pre-fusion-labelled run higher by 72.89%. The training time differs by 223.346 seconds, or 13.98% of the longer run.

These are descriptive differences between two archived executions. They are not estimates of a fusion effect. No repeated seed, confidence interval, or independent pre-fusion implementation is retained. Wall-clock time is also sensitive to GPU contention and host load.

### 5.3 Claims removed or downgraded

| Earlier claim | Status in this paper | Reason |
| --- | --- | --- |
| Two fusion mechanisms were compared under controlled conditions | Downgraded | No independent pre-fusion control in the current entry point |
| Pre-fusion is 0.71% better | Descriptive only | One run per label and no causal separation |
| Cross-attention is 42% better on PDE residual | Descriptive only | Different metric value, unresolved implementation attribution |
| Physics weight was 0.1 during training | Removed | Stored training value is 0.0; 0.1 is the validation weight |
| Learning rate was 3e-3 | Removed | Stored value is 1e-3 |
| Different fusion paths have different parameter counts | Removed | Both checkpoints contain 341,026 parameters and matching signatures |

The audit does not imply that fusion strategy is unimportant. It shows that the archived artifacts cannot identify the strategy effect. A future comparison needs an explicit strategy switch, a saved architecture manifest, matched budgets, and repeated seeds.

## 6 Results

### 6.1 Matched periodic-shift experiment

The matched comparison keeps the model, data source, optimization budget, and evaluation split fixed. The only intended change is the training set: 1,408 original trajectories versus 4,224 trajectories produced by two exact shift copies.

| Seed | Original test L2 | Shifted test L2 | Absolute change | Relative change |
| ---: | ---: | ---: | ---: | ---: |
| 11 | 0.097000 | 0.090097 | -0.006903 | -7.12% |
| 7 | 0.102857 | 0.095846 | -0.007011 | -6.82% |
| 23 | 0.110597 | 0.105622 | -0.004975 | -4.50% |
| Mean | 0.103485 | 0.097188 | -0.006296 | -6.09% |
| Standard deviation | 0.006820 | 0.007849 | - | - |

All three paired runs improve. The development relative L2 also improves for all three seeds:

| Seed | Original dev L2 | Shifted dev L2 | Relative change |
| ---: | ---: | ---: | ---: |
| 11 | 0.109650 | 0.104754 | -4.47% |
| 7 | 0.119245 | 0.109762 | -7.95% |
| 23 | 0.126335 | 0.114474 | -9.39% |

The mean test improvement is 6.09%, but the sample contains three seeds. The result is evidence of a repeatable effect on this benchmark, not a universal augmentation law.

### 6.2 PDE residual is not a consistent win

The shifted runs do not improve the PDE residual uniformly:

| Seed | Original test PDE RMS | Shifted test PDE RMS |
| ---: | ---: | ---: |
| 11 | 0.838240 | 0.855308 |
| 7 | 1.354726 | 1.738279 |
| 23 | 1.524887 | 1.471190 |
| Mean | 1.239284 | 1.354926 |

The mean residual increases by about 9.3%, while the L2 error improves. This is a useful negative observation. Exact shift augmentation improves positional coverage and field accuracy, but it does not guarantee a lower sampled residual under the current diagnostic.

The discrepancy can arise from several sources: the validation uses the PDE term only as a diagnostic, the residual is sampled at random coordinates, and the checkpoint is selected by a combined development score. The result should not be framed as proof that augmentation improves physical consistency.

### 6.3 Preliminary sensor-fusion result

A single seed-11 comparison adds eight sensors at \(t_s=0.5\) to the same 1,408-trajectory training recipe. It increases the parameter count from 336,546 to 341,026.

| Seed 11 | Field only | Eight sensors |
| --- | ---: | ---: |
| Test relative L2 | 0.097000 | 0.115319 |
| Test PDE RMS | 0.838240 | 1.038709 |
| Parameters | 336,546 | 341,026 |

The sensor run is worse on both recorded metrics. This is a preliminary negative result, not a controlled fusion conclusion: it has one seed, the sensor run carries additional parameters, and the sensor loss does not include a cross-modal alignment term. The result nevertheless argues against the assumption that adding informative measurements automatically improves the operator.

One plausible explanation is that the sensor branch learns a shortcut based on fixed locations or the single sampling time. The field path already contains the initial condition, so the sensor token can be useful only if the optimization aligns it with the predictive task. Concatenation alone does not create that alignment.

### 6.4 Training behavior

The representative shifted run reaches its best dev score at step 22,000. Its test prediction is shown below.

![Figure 2. Representative test prediction](experiments/outputs_burgers_dataset/custom_v13_shift3_24k/test_prediction.png)

Figure 2. Representative test prediction for the shifted, field-only model with seed 11.

![Figure 3. Training and validation curves](experiments/outputs_burgers_dataset/custom_v13_shift3_24k/training_curve.png)

Figure 3. Training history for the representative shifted run.

The three shifted runs complete 24,000 steps and select best checkpoints at 22,000, 20,000, and 18,000. The field-only model therefore remains reasonably stable over the scheduled budget, but the final training state is not always the best test state.

## 7 Reproducibility Protocol for the Missing Fusion Study

### 7.1 Narrow research question

The next experiment should test a falsifiable question:

> Under matched data, parameter budget, optimization budget, evaluation queries, and checkpoint rule, does a separately implemented pre-fusion model differ from the current hybrid token-fusion model in joint prediction error and PDE residual?

The question should not assume a winner. A result with overlapping uncertainty is scientifically useful.

### 7.2 Required implementations

At least four systems should be compared:

1. Field-only baseline.
2. Early feature fusion with a shared joint encoder.
3. Representation-level attention fusion with modality-specific encoders.
4. The current hybrid token-fusion implementation.

Each implementation needs a unit-tested forward path. The test suite should verify token counts, tensor shapes, gradient flow, and the absence of sensor information in the field-only branch.

### 7.3 Architecture fingerprint

Every run should save a manifest with:

- fusion mode and implementation identifier;
- module class list;
- parameter count;
- hash of parameter shapes;
- source hash or Git commit;
- exact training objective and realized loss-weight schedule;
- data split hashes;
- checkpoint selection rule;
- evaluation query seed.

A directory name alone is insufficient provenance.

### 7.4 Experimental matrix

| Factor | Minimum setting |
| --- | --- |
| Sensor count | 0, 4, 8, 16 |
| Sensor time | 0.2, 0.5, 0.8 |
| Seeds | at least 5 paired seeds |
| Budget | matched steps and a separate matched wall-clock arm |
| Loss | fixed primary weight plus a documented sensitivity study |
| Metrics | relative L2, fixed-query PDE RMS, per-time error, spectral error |
| Reporting | mean, standard deviation, paired differences, bootstrap intervals |

The sensor matrix should be run only after the implementation fingerprint and field-only controls pass.

### 7.5 Multimodal alignment objective

Direct concatenation is not enough. A minimally plausible alignment objective is

$$
\mathcal{L}_{\mathrm{align}}
=\sum_i\lVert\hat{u}(x_i,t_s)-u_i\rVert^2
+\lVert\hat{u}_{\mathrm{field+sensor}}
-\hat{u}_{\mathrm{field-only}}\rVert^2.
$$

The first term requires the field prediction to explain the sensor readings. The second encourages consistent predictions in regions where both paths are expected to agree. Modality dropout should be used during training so the field-only path remains a valid fallback.

## 8 Limitations

This study has six main limitations.

First, it evaluates one PDE, one spatial resolution, and one boundary condition. The data span five viscosities rather than a single coefficient. Periodic shifts are exact only for periodic fields and cannot be transferred directly to non-periodic domains.

Second, the positive augmentation result uses three paired seeds. This is enough to show a repeated improvement, not enough to estimate a population-level effect or justify a small-effect significance claim.

Third, the PDE residual is a random-query diagnostic evaluated with a nominal viscosity rather than the sample-specific value. Its mean changed in the opposite direction from the field error. Future evaluations should save a fixed query set, use the correct per-sample coefficient, and report the residual definition and normalization.

Fourth, the sensor branch was tested with one seed and no alignment loss. The negative result is informative for engineering caution but is not a definitive fusion comparison.

Fifth, the archived fusion runs lack an independent pre-fusion implementation and source commit. The numerical differences remain useful as historical observations, but not as causal evidence.

Sixth, the model is not an engineering replacement for a numerical solver. The operator has about 337 thousand parameters and trains for roughly 47 to 52 minutes on the retained hardware. It is a research prototype for controlled operator-learning experiments.

## 9 Conclusion

This paper separates what the multimodal operator project has demonstrated from what it has only suggested.

The demonstrated result is an exact periodic-shift augmentation effect. On three paired runs, mean test relative L2 improves by 6.09%, with all three seeds improving. The change preserves the PDE exactly and isolates the effect of positional coverage. The PDE residual does not improve consistently, so the result should be described as an accuracy and coverage benefit.

The multimodal claim is not yet demonstrated. Direct sensor tokens increase error in the retained trial, and the archived cross-attention versus pre-fusion comparison cannot be attributed because the stored configurations and parameter signatures do not identify two separate mechanisms. The appropriate next step is not another architectural label. It is an executable comparison with saved fingerprints, paired seeds, fixed evaluation queries, and a cross-modal alignment objective.

The broader lesson is simple. Exact symmetries can provide reliable data augmentation when the governing physics is known. Merely adding another modality does not guarantee a better operator. In multimodal scientific machine learning, the evidence for interaction must be as explicit as the architecture diagram.

## Data and Code Availability

The manuscript uses retained artifacts in the project workspace:

- `code/demo_burgers_dataset.py`
- `code/make_custom_shift_augment.py`
- `datasets/burgers_custom_v1/`
- `experiments/outputs_burgers_dataset/custom_v7_hp05_24k*`
- `experiments/outputs_burgers_dataset/custom_v13_shift3_24k*`
- `experiments/outputs_burgers_dataset/custom_v11_multimodal_sensors8_24k/`
- `experiments/outputs_burgers_dataset/custom_v12_multimodal_prefusion_24k/`

A publication release should include checksums for the data files, all retained metrics, the training command lines, the environment lock file, and the architecture manifests.

## References

[1] Z. Li, N. Kovachki, K. Azizzadenesheli, B. Liu, K. Bhattacharya, A. Stuart, and A. Anandkumar. Fourier Neural Operator for Parametric Partial Differential Equations. International Conference on Learning Representations, 2021.

[2] L. Lu, P. Jin, G. Pang, Z. Zhang, and G. E. Karniadakis. Learning Nonlinear Operators via DeepONet Based on the Universal Approximation Theorem of Operators. Nature Machine Intelligence, 3:218-229, 2021.

[3] N. Kovachki, Z. Li, B. Liu, K. Azizzadenesheli, K. Bhattacharya, A. Stuart, and A. Anandkumar. Neural Operator: Learning Maps Between Function Spaces with Applications to PDEs. Journal of Machine Learning Research, 24(89):1-97, 2023.

[4] M. Takamoto, T. Praditia, R. Leiteritz, D. MacKinlay, F. Alesiani, D. Pfluger, and M. Niepert. PDEBench: An Extensive Benchmark for Scientific Machine Learning. NeurIPS Datasets and Benchmarks Track, 2022.

[5] M. Raissi, P. Perdikaris, and G. E. Karniadakis. Physics-Informed Neural Networks: A Deep Learning Framework for Solving Forward and Inverse Problems Involving Nonlinear Partial Differential Equations. Journal of Computational Physics, 378:686-707, 2019.

[6] S. Wang, H. Wang, and P. Perdikaris. Learning the Solution Operator of Parametric Partial Differential Equations with Physics-Informed DeepONets. Science Advances, 7(40):eabi8605, 2021.

[7] A. Baltrušaitis, C. Ahuja, and L.-P. Morency. Multimodal Machine Learning: A Survey and Taxonomy. IEEE Transactions on Pattern Analysis and Machine Intelligence, 41(2):423-443, 2019.

[8] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, L. Kaiser, and I. Polosukhin. Attention Is All You Need. Advances in Neural Information Processing Systems, 2017.

[9] A. Krishnapriyan, A. Gholami, S. Zhe, R. Kirby, and M. W. Mahoney. Characterizing Possible Failure Modes in Physics-Informed Neural Networks. Advances in Neural Information Processing Systems, 2021.

[10] J. Pineau, P. Vincent-Lamarre, K. Sinha, V. Lariviere, A. Beygelzimer, F. d'Alche-Buc, E. Fox, and H. Larochelle. Improving Reproducibility in Machine Learning Research. Journal of Machine Learning Research, 22(164):1-20, 2021.

[11] B. Efron and R. J. Tibshirani. An Introduction to the Bootstrap. Chapman and Hall/CRC, 1993.

## Appendix A Run Provenance

| Role | Directory | Seed | Train samples | Parameters |
| --- | --- | ---: | ---: | ---: |
| Original augmentation control | `custom_v7_hp05_24k` | 11 | 1,408 | 336,546 |
| Original augmentation control | `custom_v7_hp05_24k_seed7` | 7 | 1,408 | 336,546 |
| Original augmentation control | `custom_v7_hp05_24k_seed23` | 23 | 1,408 | 336,546 |
| Periodic-shift run | `custom_v13_shift3_24k` | 11 | 4,224 | 336,546 |
| Periodic-shift run | `custom_v13_shift3_24k_seed7` | 7 | 4,224 | 336,546 |
| Periodic-shift run | `custom_v13_shift3_24k_seed23` | 23 | 4,224 | 336,546 |
| Eight-sensor trial | `custom_v11_multimodal_sensors8_24k` | 11 | 1,408 | 341,026 |
| Archived fusion label | `custom_v12_multimodal_prefusion_24k` | 11 | 1,408 | 341,026 |

## Appendix B Minimum Reporting Checklist

- [ ] Fusion mode and implementation identifier recorded in every run
- [ ] Architecture manifest and parameter-shape hash saved
- [ ] Source commit or code hash retained
- [ ] Exact training objective and realized loss schedule logged
- [ ] Data split hashes retained
- [ ] Checkpoint-selection rule applied consistently
- [ ] Fixed evaluation query set saved for PDE diagnostics
- [ ] At least five paired seeds for comparative claims
- [ ] Mean, standard deviation, and paired uncertainty reported
- [ ] Failed and non-finite runs included in the analysis
- [ ] Field-only baseline included
- [ ] Negative and inconclusive results reported

